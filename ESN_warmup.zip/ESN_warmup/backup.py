scale_input = 0.73
scale_bias = 0.02
scale_state = 0.05
max_param = 1
min_param = -1
params_mu = 1
ridge_k = 0.001